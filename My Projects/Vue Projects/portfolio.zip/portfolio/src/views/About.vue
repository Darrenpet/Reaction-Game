<template>
  <div class="container text-start my-5">
    <div class="row">
      <div class="col-lg-12 col-sm-12">
        <h2 class="fw-bold">About Me</h2>
        <p class="text-muted">
          I am a hard-working, diligent and patient individual. I am rather a
          shy fellow, but with time and getting to know people more I become
          more confident. Not only that, but I am very respectful of my
          surroundings and people around me, and believe in treating people the
          way I would like to be treated. Always willing to help if I can, and
          always willing to learn new things.
        </p>
        <h6 class="fw-bold">Passion Board</h6>
        <p class="text-muted">
          Watching YouTube channels, sports(rugby, cricket, football, lawn
          bowls), Gaming on my mobile/pc, Outdoor activities watching live
          games(rugby, cricket, football),
        </p>
        <h6 class="fw-bold">Soft Skills</h6>
        <p class="text-muted">
          Teamwork, Critical thinker, Problem-solving, Time management,
          adaptability, Strong work ethic, Leadership skills.
        </p>
        <ul class="social-links list-inline">
          <li class="list-inline-item">
            <a
              href="https://github.com/Darrenpet"
              title="Github"
              target="_blank"
            >
              <i class="bi bi-github" style="font-size: 2rem"></i
            ></a>
          </li>
          <li class="list-inline-item">
            <a
              href="https://app.netlify.com/teams/darrenpet/overview"
              title="Netlify"
              target="_blank"
            >
              <i
                ><span
                  class="iconify mx-2"
                  data-icon="simple-icons:netlify"
                  style="font-size: 2rem"
                ></span></i
            ></a>
          </li>
          <li class="list-inline-item">
            <a
              href="https://www.linkedin.com/in/darren-petersen-45a381224/"
              title="Linkedin"
              target="_blank"
            >
              <i class="bi bi-linkedin" style="font-size: 2rem"></i
            ></a>
          </li>
        </ul>
        <a class="btn btn-dark" href="#Projects" title="Download CV"
          >Projects</a
        >
      </div>
    </div>
  </div>
  
  <div class="container my-5 shadow-5-strong">
    <div class="row">
      <div class="col-xl-3 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">40 %</h3>
                <p class="mb-0">HTML</p>
              </div>
              <div class="align-self-center">
                <i class="fab fa-html5 text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 40%"
                  aria-valuenow="40"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">35 %</h3>
                <p class="mb-0">CSS</p>
              </div>
              <div class="align-self-center">
                <i class="fab fa-css3-alt text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 35%"
                  aria-valuenow="35"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">30 %</h3>
                <p class="mb-0">JavaScript</p>
              </div>
              <div class="align-self-center">
                <i class="fab fa-js-square text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 30%"
                  aria-valuenow="30"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">25 %</h3>
                <p class="mb-0">Vue</p>
              </div>
              <div class="align-self-center">
                <i class="fab fa-vuejs text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 25%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">25 %</h3>
                <p class="mb-0">MySQL</p>
              </div>
              <div class="align-self-center">
                <i class="fas fa-database text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 25%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">35 %</h3>
                <p class="mb-0">Front End Development</p>
              </div>
              <div class="align-self-center">
                <i class="fas fa-desktop text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 35%"
                  aria-valuenow="35"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between text-start px-md-1">
              <div>
                <h3 class="text-primary">30 %</h3>
                <p class="mb-0">Back End Development</p>
              </div>
              <div class="align-self-center">
                <i class="fas fa-server text-primary fa-3x"></i>
              </div>
            </div>
            <div class="px-md-1">
              <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                <div
                  class="progress-bar bg-dark progress-bar-animated"
                  role="progressbar"
                  style="width: 30%"
                  aria-valuenow="30"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
.progress {
  background-color: whitesmoke;
}
</style>
