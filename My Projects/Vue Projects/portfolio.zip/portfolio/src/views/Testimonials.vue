<template>
  <h2 class="fw-bold">Testimonials</h2>
  <div class="container shadow-5-strong my-5">
    <div class="row">
      <div class="col-xl-6 col-md-6 col-sm-12">
        <div class="card testimonial-card mt-2 mb-3">
          <div class="card-up aqua-gradient"></div>
          <div class="avatar mx-auto white">
            <img
              src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2831%29.jpg"
              class="rounded-circle img-fluid"
              alt="Kagiso"
            />
          </div>
          <div class="card-body text-center">
            <h4 class="card-title font-weight-bold">Kagsio Mphayi</h4>
            <hr />
            <p>
              <i class="fas fa-quote-left"></i> Darren is a smart working
              individual who is always focused. He shows great attention to
              detail and has good time management skills.
              <i class="fas fa-quote-right"></i>
            </p>
            <p class="card-text">
              <small class="text-muted">Class 1 colleague</small>
            </p>
          </div>
        </div>
      </div>

      <div class="col-xl-6 col-md-6 col-sm-12">
        <div class="card testimonial-card mt-2 mb-3">
          <div class="card-up aqua-gradient"></div>
          <div class="avatar mx-auto white">
            <img
              src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2831%29.jpg"
              class="rounded-circle img-fluid"
              alt="Jordan"
            />
          </div>
          <div class="card-body text-center">
            <h4 class="card-title font-weight-bold">Jordan Dawson</h4>
            <hr />
            <p>
              <i class="fas fa-quote-left"></i> Darren Petersen is a hard and
              quick student who picks up on things extremely easily and is very
              adaptable to most situations. He is also very dedicated to his
              work and will put extra effort and time where it needs to be put
              into.
              <i class="fas fa-quote-right"></i>
            </p>
            <p class="card-text">
              <small class="text-muted">Class 1 colleague</small>
            </p>
          </div>
        </div>
      </div>

      <div class="col-xl-6 col-md-6 col-sm-12">
        <div class="card testimonial-card mt-2 mb-3">
          <div class="card-up aqua-gradient"></div>
          <div class="avatar mx-auto white">
            <img
              src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2831%29.jpg"
              class="rounded-circle img-fluid"
              alt="Mullins"
            />
          </div>
          <div class="card-body text-center">
            <h4 class="card-title font-weight-bold">Abdul Atheem Mullins</h4>
            <hr />
            <p>
              <i class="fas fa-quote-left"></i> Darren is one of the most
              honest, hardworking, inspiring and dedicated pupil i know. Darren
              always strives to complete any task to the best of his ability.
              <i class="fas fa-quote-right"></i>
            </p>
            <p class="card-text">
              <small class="text-muted">Class 1 colleague</small>
            </p>
          </div>
        </div>
      </div>

      <div class="col-xl-6 col-md-6 col-sm-12">
        <div class="card testimonial-card mt-2 mb-3">
          <div class="card-up aqua-gradient"></div>
          <div class="avatar mx-auto white">
            <img
              src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2831%29.jpg"
              class="rounded-circle img-fluid"
              alt="Ubaid"
            />
          </div>
          <div class="card-body text-center">
            <h4 class="card-title font-weight-bold">Ubaidullah Breda</h4>
            <hr />
            <p>
              <i class="fas fa-quote-left"></i> Darren is a person with a
              wonderful character, he always shares the information that he has
              and is very easy to work with while motivating me to do better.
              <i class="fas fa-quote-right"></i>
            </p>
            <p class="card-text">
              <small class="text-muted">Class 1 colleague</small>
            </p>
          </div>
        </div>
      </div>

      <div class="col-xl-6 col-md-6 col-sm-12">
        <div class="card testimonial-card mt-2 mb-3">
          <div class="card-up aqua-gradient"></div>
          <div class="avatar mx-auto white">
            <img
              src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2831%29.jpg"
              class="rounded-circle img-fluid"
              alt="Hannah"
            />
          </div>
          <div class="card-body text-center">
            <h4 class="card-title font-weight-bold">Hannah Dalwai</h4>
            <hr />
            <p>
              <i class="fas fa-quote-left"></i> Darren is a hardworking
              individual and always ready to help a teamate in need.
              <i class="fas fa-quote-right"></i>
            </p>
            <p class="card-text">
              <small class="text-muted">Class 2 colleague</small>
            </p>
          </div>
        </div>
      </div>

      <div class="col-xl-6 col-md-6 col-sm-12">
        <div class="card testimonial-card mt-2 mb-3">
          <div class="card-up aqua-gradient"></div>
          <div class="avatar mx-auto white">
            <img
              src="https://mdbootstrap.com/img/Photos/Avatars/img%20%2831%29.jpg"
              class="rounded-circle img-fluid"
              alt="Mr.G"
            />
          </div>
          <div class="card-body text-center">
            <h4 class="card-title font-weight-bold">Godwin Dzvapatsva</h4>
            <hr />
            <p>
              <i class="fas fa-quote-left"></i> Darren shows a lot of creativity
              in coding classes It's a pleasure watching him focus on the work
              in class. I am cheering Darren on to do well in web development.
              <i class="fas fa-quote-right"></i>
            </p>
            <p class="card-text">
              <small class="text-muted">Head of Curriculum and Learning</small>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
