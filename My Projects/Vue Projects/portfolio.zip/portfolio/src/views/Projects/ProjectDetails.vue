<template>
  <div v-if="project">
    <h2 class="fw-bold">Project Details</h2>
    <p>The project id is {{ id }}</p>
  </div>

  <div
    class="card border border-primary shadow-0 text-white"
    style="background-color: #000000"
  >
    <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
      <img src="{{ project.img }}" class="img-fluid" />
      <a href="#!">
        <div
          class="mask"
          style="background-color: rgba(251, 251, 251, 0.15)"
        ></div>
      </a>
    </div>
    <div class="card-header">Featured</div>
    <div class="card-body">
      <h5 class="card-title">{{ project.title }}</h5>
      <p class="card-text">
        {{ project.details }}
      </p>

      <button type="button" class="btn btn-primary">Button</button>
    </div>
    <div class="card-footer">
      <a
        href="https://github.com/Darrenpet/CRUD-Excercise"
        class="card-link"
        target="_blank"
        ><i class="bi bi-github mx-2" style="font-size: 2rem"></i>Github</a
      >
      <a
        href="https://awesome-davinci-9bf4c2.netlify.app/"
        class="card-link"
        target="_blank"
        ><i
          ><span
            class="iconify mx-2"
            data-icon="simple-icons:netlify"
            style="font-size: 2rem"
          ></span></i
        >Netlify</a
      >
    </div>
  </div>
</template>

<script>
export default {
  props: ["id"],
  data() {
    return {
      project: null,
    };
  },
  mounted() {
    fetch("http://localhost:3000/projects/" + this.id)
      .then((res) => res.json())
      .then((data) => (this.projects = data))
      .catch((err) => console.log(err.message));
  },
};
</script>

<style></style>
