<template>
  <h1 class="fw-bold">404</h1>
  <h2 class="fw-bold">Page Not Found</h2>
</template>

<script>
export default {};
</script>

<style></style>
